﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace GroupingSampleListView
{
	public partial class GroupedListXaml : ContentPage
	{

		private ObservableCollection<GroupedVeggieModel> groupedAll { get; set; }

		private ObservableCollection<GroupedVeggieModel> grouped { get; set; }

		int ItemsCount = 0;

		public GroupedListXaml ()
		{
			InitializeComponent ();
			grouped = new ObservableCollection<GroupedVeggieModel> ();

			CreateAllList();

			for(int i=0;i<2;i++)
            {
				grouped.Add(groupedAll[i]);
            }

			lstView.ItemsSource = grouped;
		}

        private async void lstView_ItemAppearing(object sender, ItemVisibilityEventArgs e)
        {
			int index = e.ItemIndex;

			var model = grouped[grouped.Count - 1];

			int currentCount = model[model.Count - 1].Id;

			if(index ==currentCount-1)
            {
				if(grouped.Count<groupedAll.Count)
                {
					dialog.IsRunning = true;
					await Task.Delay(2000);
					
					grouped.Add(groupedAll[grouped.Count]);  // add one group each time
					dialog.IsRunning = false;
				}

				else
                {
					DisplayAlert("Ttile","Data Loaded finished!","OK");
                }
            }


		}


		void CreateAllList()
        {
			groupedAll = new ObservableCollection<GroupedVeggieModel>();
			var AAAGroup = new GroupedVeggieModel() { LongName = "AAA", ShortName = "a" };
			var BBBGroup = new GroupedVeggieModel() { LongName = "BBB", ShortName = "b" };
			var CCCGroup = new GroupedVeggieModel() { LongName = "CCC", ShortName = "c" };
			var DDDGroup = new GroupedVeggieModel() { LongName = "DDD", ShortName = "d" };
			var EEEGroup = new GroupedVeggieModel() { LongName = "EEE", ShortName = "e" };
			var FFFGroup = new GroupedVeggieModel() { LongName = "FFF", ShortName = "f" };
			var GGGGroup = new GroupedVeggieModel() { LongName = "GGG", ShortName = "g" };
			var HHHGroup = new GroupedVeggieModel() { LongName = "HHH", ShortName = "h" };


			groupedAll.Add(AAAGroup);
			groupedAll.Add(BBBGroup);
			groupedAll.Add(CCCGroup);
			groupedAll.Add(DDDGroup);
			groupedAll.Add(EEEGroup);
			groupedAll.Add(FFFGroup);
			groupedAll.Add(GGGGroup);
			groupedAll.Add(HHHGroup);

			foreach(GroupedVeggieModel model in groupedAll )
            {
				for(int i=0; i<15; i++)
                {
					model.Add(new VeggieModel() { Id = ItemsCount, Name = "items" + ItemsCount.ToString() });
					ItemsCount++;
                }
            }
			

		}

    }
}

